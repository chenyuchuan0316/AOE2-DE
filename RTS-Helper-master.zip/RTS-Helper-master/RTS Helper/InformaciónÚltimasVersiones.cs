﻿using System;



public class InformaciónÚltimasVersiones {


    public string? Version { get; set; }

    public string? Url { get; set; }

    public string? ChangelogUrl { get; set; }

    public int? ImagesVersion { get; set; } = null;

    public int? BuildOrdersVersion { get; set; } = null;

    public int? SoundsVersion { get; set; } = null;

    public string? BaseUrl { get; set; } = null;


} // InformaciónÚltimasVersiones>
